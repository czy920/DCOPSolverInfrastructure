import datetime
import sys
import os
path = os.path.dirname(os.path.dirname(__file__))
sys.path.append(path+'/DCOPPharse/')
sys.path.append(path+'/CycleQueue/')
sys.path.append(path+'/DCOPGenetor/')
sys.path.append(path+'/algorithm/DPOP/')
sys.path.append(path+'/algorithm/DSA/')
from PyQt5 import QtCore, QtGui, QtWidgets
from GUIGenetor import *
from multiprocessing import Process
from DCOPGenetor import *
from ProblemParse import *
from graphviz import Graph,Digraph
from Problem import *
from AgentManagerCycle import *
from MessageMailerCycle import *
import matplotlib.pylab as plt # 导入绘图包
import matplotlib.pyplot as mp
import numpy as np
import cv2








if __name__ == '__main__':
    parser=ProblemParser(path+'/RandomDCOP_10_10_1.xml', "DFS")
    problem=parser.parse()
    h = DFSgraph(problem)
    h.view(path+'/Graph/DFS.gv')
    agentManagerCycle = AgentManagerCycle(problem,'DPOP',1000,0.4)
    msgMailer = MessageMailerCycle(agentManagerCycle,'DPOP')
    msgMailer.startProcess()
    msgMailer.initWait()   #为避免出现Agent线程开始而Mailer未初始化完成而出现错误
    agentManagerCycle.startAgents(msgMailer)
    msgMailer.join()
    print(msgMailer.re)