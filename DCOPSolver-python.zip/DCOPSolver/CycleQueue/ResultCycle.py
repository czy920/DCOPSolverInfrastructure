from Result import *

class ResultCycle(Result):
    def __init__(self):
        
        super().__init__(None)
        self.totalCostInCycle = []
        self.timeCostInCycle = []
        self.messageQuantityInCycle = []
        self.nccc = 0
        self.DEBUG = None



    

      


