# DCOPSolver

## This is an algorithm verification platform for verifying Distributed Constrained Optimization Problems.



## Requirements
- Python 3.0 or higher
- Graphviz
- install requirements.txt



## Getting Started
- Run main.py in the main folder or Solver.py in the Solver folder. 



